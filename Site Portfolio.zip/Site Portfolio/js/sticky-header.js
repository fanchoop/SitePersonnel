// JavaScript Document
 
  $(document).ready(function(){
  	"use strict";
	 if( $( window ).width() >= "768" ) {
		$(".navigation").sticky({topSpacing:0});	
    }

  });
  